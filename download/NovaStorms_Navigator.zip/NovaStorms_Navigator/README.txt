NovaStorms Navigator
MBAN 6600 Analytics in Action

Live dashboard:
https://analyticsblackpoint-bot.github.io/AnalyticsInAction-Naviguator/

What is in this folder

  NovaStorms_Navigator_dashboard.html
    The dashboard. Open it in any web browser. It works offline.

  NovaStorms_Navigator_Deck.pptx
    The presentation: 9 slides and one backup slide.

  NovaStorms_Data_Report.pdf
  NovaStorms_Data_Report.docx
    The full report (65 pages), as PDF and as Word.

The recommendation

  Pilot in Halifax and test price first.
  Learn to sell in Toronto, then earn in Paris.

Where the numbers come from

  Every number in the report, the deck and the dashboard comes from one
  checked file of public data. Appendix A of the report lists each number
  with its source.
